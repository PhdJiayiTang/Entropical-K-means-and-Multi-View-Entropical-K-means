function [label, center, prevtotsumD, assign] = Entropical_kmeans(X, k, varargin)


%%
epsilon=0.0001;
aa = full(sum(X.*X,2));
%%
if nargin < 2
    error('litekmeans:TooFewInputs','At least two input arguments required.');
end

[n, p] = size(X);


pnames = {   'distance' 'start'   'maxiter'  'replicates' 'onlinephase'};
dflts =  {'sqeuclidean' 'sample'       []        []      'off'  };
[eid,errmsg,distance,start,maxit,reps,online] = getargs(pnames, dflts, varargin{:});
if ~isempty(eid)
    error(sprintf('litekmeans:%s',eid),errmsg);
end

if ischar(distance) 
    distNames = {'sqeuclidean','cosine'};
    j = strcmpi(distance, distNames);
    j = find(j);
    if length(j) > 1
        error('litekmeans:AmbiguousDistance', ...
            'Ambiguous ''Distance'' parameter value:  %s.', distance);
    elseif isempty(j)
        error('litekmeans:UnknownDistance', ...
            'Unknown ''Distance'' parameter value:  %s.', distance);
    end
    distance = distNames{j};
else
    error('litekmeans:InvalidDistance', ...
        'The ''Distance'' parameter value must be a string.');
end


center = [];


% The maximum iteration number is default 100
if isempty(maxit)
    maxit = 100;
end

% Assume one replicate
if isempty(reps) || ~isempty(center)
    reps = 1;
end

if ~(isscalar(k) && isnumeric(k) && isreal(k) && k > 0 && (round(k)==k)) %若k为(标量，数值数组，实数，k>0，k为小数)中的任何一个
    error('litekmeans:InvalidK', ...
        'X must be a positive integer value.');
elseif n < k
    error('litekmeans:TooManyClusters', ...
        'X must have more rows than the number of clusters.');
end


bestlabel = [];
sumD = zeros(1,k);
bCon = false;

for t=1:reps
    it=0;
    S = RandStream.getGlobalStream;

% Select the first seed by sampling uniformly at random
    index = zeros(1,k);
    [center(:,1), index(1)] = datasample(S,X',1,2);
    minDist = inf(n,1);
% Select the rest of the seeds by a probabilistic model
    for ii = 2:k
        minDist = min(minDist,distfun(X',center(:,ii-1),distance));
        denominator = sum(minDist);
        if denominator==0 || isinf(denominator) || isnan(denominator)
            center(:,ii:k) = datasample(S,X',k-ii+1,2,'Replace',false);
            break;
        end
        sampleProbability = minDist/denominator;
        [center(:,ii), index(ii)] = datasample(S,X',1,2,'Replace',false,...
            'Weights',sampleProbability);
    end
    if ~isfloat(center)      % X may be logical
        center = double(center);
    end
    prevcenter = Inf;
    prevtotsumD = Inf;

    while  it<maxit

        temp_D= distfun(X', center, distance, 0, 1, reps);
        D=(temp_D-repmat(min(temp_D,[],2),1,k))./repmat(max(temp_D,[],2)-min(temp_D,[],2),1,k);
        D=exp(-D/epsilon);
        D=D./repmat(sum(D,2),1,k);
        q=sum(D,1)/n;
        mu=D./(n*repmat(q,n,1));
        center = X'*mu;

        totsumD = sum(sum(D.*temp_D));
        if prevtotsumD(end) <= totsumD
            break;
        else
            prevtotsumD = [prevtotsumD,totsumD];
            prevD=D;
        end
        
        if norm(prevcenter-center,'fro')<1E-7
            break;
        else
            prevcenter=center;
        end
        assign=prevD;    
        it=it+1;
    end
    temp=cumsum(assign,2)-repmat(rand(n,1),1,k);
    label=k+1-sum(temp>0,2);
    if it<maxit
        bCon = true;
    end
    if isempty(bestlabel)
        bestlabel = label;
        bestcenter = center;
        if reps>1
            if it>=maxit
                bb = full(sum(center.*center,1));
                ab = full(X*center);
                D = bsxfun(@plus,aa,bb) - 2*ab;
                D(D<0) = 0;
            else
                D = aa(:,ones(1,k)) + D;
                D(D<0) = 0;
            end
            D = sqrt(D);
            for j = 1:k
                sumD(j) = sum(D(label==j,j));
            end
            bestsumD = sumD;
            bestD = D;
        end
    else
        if it>=maxit
            bb = full(sum(center.*center,1));
            ab = full(X*center);
            D = bsxfun(@plus,aa,bb) - 2*ab;
            D(D<0) = 0;
        else
            D = aa(:,ones(1,k)) + D;
            D(D<0) = 0;
        end
        D = sqrt(D);
        for j = 1:k
            sumD(j) = sum(D(label==j,j));
        end
        if sum(sumD) < sum(bestsumD)
            bestlabel = label;
            bestcenter = center;
            bestsumD = sumD;
            bestD = D;
        end
    end
end

label = bestlabel;
center = bestcenter;
if reps>1
    sumD = bestsumD;
    D = bestD;
elseif nargout > 3
    switch distance
        case 'sqeuclidean'
            if it>=maxit
                bb = full(sum(center.*center,1));
                ab = full(X*center);
                D = bsxfun(@plus,aa,bb) - 2*ab;
                D(D<0) = 0;
            else
                D = aa(:,ones(1,k)) + D;
                D(D<0) = 0;
            end
            D = sqrt(D);
    end
    for j = 1:k
        sumD(j) = sum(D(label==j,j));
    end
end


function D = distfun(X, C, dist, iter,rep, reps)
%DISTFUN Calculate point to cluster centroid distances.

switch dist
    case 'sqeuclidean'
        D = internal.stats.pdist2mex(X,C,'sqe',[],[],[],[]);  
    case {'cosine','correlation'}
        % The points are normalized, centroids are not, so normalize them
        normC = sqrt(sum(C.^2, 1));
        if any(normC < eps(class(normC))) % small relative to unit-length data points
            if reps==1
                error(message('stats:kmeans:ZeroCentroid', iter));
            else
                error(message('stats:kmeans:ZeroCentroidRep', iter, rep));
            end
            
        end
        C = C./normC;
        D = internal.stats.pdist2mex(X,C,'cos',[],[],[],[]);  
end
end % function

%------------------------------------------------------------------
end
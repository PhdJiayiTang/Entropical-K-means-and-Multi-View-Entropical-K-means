clc
clear
% addpath(genpath('/measure'));
Data={'yaleA_3view','Handwritten_numerals','cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','stl10_fea_Per1','SUNRGBD_fea_Per1'};
Name={'yaleA_3view','Handwritten_numerals','cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','stl10_fea_Per1','SUNRGBD_fea_Per1'};
iii=1;
if strcmp(Data{iii},'yaleA_3view') || strcmp(Data{iii},'Handwritten_numerals') || strcmp(Data{iii},'ORL_mtv')  || strcmp(Data{iii},'Wiki_fea') || strcmp(Data{iii},'WebKB_2views') 
    load(strcat('D:\BBC\multi-view-dataset\',Data{iii},'.mat'));
elseif strcmp(Data{iii},'CiteSeer')
    load('‪D:\BBC\Multi-view_Graph_Learning-master\data\CiteSeer.mat');
    X=fea;
    Y=gt;
else
    load(strcat('D:\Incomplete multi-view datasets\',Data{iii},'.mat'));
    X=data;
    Y=truelabel{1,1};
end
type='euclidean';
% type='cosine';
clear data truelabel MissingStatus index

knn=5; %'stl10_fea_Per1',knn=5 or 3, type='euclidean'不错；对于yaleA_3view，'cosine'或者'euclidean'都不错，knn=5；Reuters，euclidean，k=15；Handwritten_numerals，type='euclidean'，MVC_EKD-k=5，MVC_EKR-5=10
num_view = length(X);  
num_sample = length(Y);
numClust = length(unique(Y));
affinity = cell(num_view,1);
Result=cell(num_view,1);
time_km=0;
time_Ekm=0;
for i=1:num_view
    try

        if strcmp(Data{iii},'Reuters_Per1')
            load([Data{iii},'_kernel',num2str(i),'.mat']);
        else
            load(['G:\新的算法尝试8\',Data{iii},'_kernel',num2str(i),'.mat']);
        end
    catch
        if size(X{i},1)==num_sample 
            W = make_affinity_matrix(X{i}, type);
        else
            W = make_affinity_matrix(X{i}', type);
        end
        save([Data{iii},'_kernel',num2str(i),'.mat'],'W');
%         original_affinity{i} = W;
    end
    if knn ~= 0  % not using fully connected graph
        [W, ~] = kNN(W, knn);
        [ W] = SpectralClustering(W, numClust, 3);
        for t=1:10
            tic
            label=litekmeans(W, numClust);
            time_km=time_km+toc;
            result(t,:)= ClusteringMeasure(Y, label);
            tic
            [label2, ~, D]=Entropical_kmeans(W, numClust);
            time_Ekm=time_Ekm+toc;
            result2(t,:)= ClusteringMeasure(Y, label2);
        end
    end
    Result{i,1} = result;
    Result2{i,1} = result2;
    affinity{i,1} = W;
end

time_km=time_km/(10*num_view);
time_Ekm=time_Ekm/(10*num_view);
clear W original_affinity idx X
clc
epsilon=1e-4;
T2_v2=0;
T3_v2=0;
for t=1:10
tic
[label2_v2, ~, ~, TotsumD2_v2] = MVC_EKD(affinity, numClust, epsilon);%,'Distance','cosine'
T2_v2=T2_v2+toc;
result2_v2(t,:)= Clustering8Measure(Y,label2_v2);% [ACC nmi Purity Fscore Precision Recall AR Entropy]
TTotsumD2_v2{t}=TotsumD2_v2;
tic
[label3_v2, ~, ~,TotsumD3_v2] = MVC_EKR(affinity, numClust, epsilon);
T3_v2=T3_v2+toc;
result3_v2(t,:)= Clustering8Measure(Y,label3_v2);% [ACC nmi Purity Fscore Precision Recall AR Entropy]
TTotsumD3_v2{t}=TotsumD3_v2;
end
T2_v2=T2_v2/10;
T3_v2=T3_v2/10;
mean(result2_v2)
mean(result3_v2)

